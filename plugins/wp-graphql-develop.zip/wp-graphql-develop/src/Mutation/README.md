# Mutation
This directory contains registrations for mutations. 

In GraphQL the `mutation` keyword signifies that something in the graph will be changing as a result of the request. 

This directory contains registrations for mutations. 

Learn more about GraphQL mutations here: https://graphql.org/learn/queries/#mutations
